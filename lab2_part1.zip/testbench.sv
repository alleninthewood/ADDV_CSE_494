///////////////////////////////////////////////////////////////////////////////////////////
// Testbench for the 5-stage pipelined MIPS processor
//
// - expected_data / expected_addr hold the expected data-memory writes, in order.
// - Every clock cycle (at the falling edge) in which memwrite = 1 is checked against
//   the next expected entry.  (The original testbench waited for @(posedge memwrite),
//   which misses back-to-back sw instructions in a pipeline, because memwrite then
//   stays high for several cycles.)
// - The program is selected with +TEST=<name>: imem loads <name>.dat and the
//   matching expected table below is used.  Default: memfile.
// - Performance: counts clock cycles and retired instructions (non-bubble
//   instructions reaching Writeback) and reports CPI / IPC when the last
//   expected store has completed.
///////////////////////////////////////////////////////////////////////////////////////////
module testbench;
    logic        clk = 1'b0;
    logic        reset;
    logic [31:0] writedata, dataadr;
    logic        memwrite;

    string       test;
    logic [31:0] expected_data[$];          // queues: size set by the chosen test
    logic [31:0] expected_addr[$];
    int          errors = 0;
    int          cycles = 0, retired = 0;

    // Instantiate top module
    top dut (.*);

    // Clock generation: 10 ns period
    always #5 clk = ~clk;

    // add one expected memory write
    function automatic void expect_write(logic [31:0] addr, logic [31:0] data);
        expected_addr.push_back(addr);
        expected_data.push_back(data);
    endfunction

    // Expected memory writes for each test program
    function automatic void load_expected();
        if (!$value$plusargs("TEST=%s", test)) test = "memfile";
        // (if/else instead of case(string): works on both VCS and Icarus)
        if (test == "memfile") begin            // all instructions
            expect_write(32'h40, 32'h11);   // add
            expect_write(32'h44, 32'h07);   // sub
            expect_write(32'h48, 32'h04);   // and
            expect_write(32'h4c, 32'h0d);   // or
            expect_write(32'h50, 32'h01);   // slt (true)
            expect_write(32'h54, 32'h00);   // slt (false)
            expect_write(32'h58, 32'h22);   // lw + add (load-use)
            expect_write(32'h5c, 32'h77);   // beq not-taken / taken
            expect_write(32'h60, 32'h77);   // j
        end else if (test == "fwd_test") begin           // ADD data hazards -> forwarding
            expect_write(32'h40, 32'd3);
            expect_write(32'h44, 32'd4);
            expect_write(32'h48, 32'd7);
            expect_write(32'h4c, 32'd14);
            expect_write(32'h50, 32'd17);
            expect_write(32'h54, 32'd34);
        end else if (test == "branch_test") begin        // BEQ control hazards -> flushing
            expect_write(32'h40, 32'd0);    // flag: wrong-path addi never executed
            expect_write(32'h44, 32'd5);
            expect_write(32'h48, 32'd2);
            expect_write(32'h4c, 32'd3);    // loop count
        end else if (test == "original") begin           // original Lab2 program
            expect_write(32'h50, 32'h7);
            expect_write(32'h54, 32'h7);
        end else begin
            $display("ERROR: unknown +TEST=%s", test);
            $finish;
        end
    endfunction

    // Performance counters: started at reset release (cycle 1 = Fetch of the
    // first instruction), then sampled every falling edge. An instruction is
    // counted when it is in Writeback (bubbles are all-zero instructions).
    // => an ideal 5-stage pipeline runs N instructions in N+4 cycles.
    task automatic count_perf();
        forever begin
            cycles++;
            if (dut.mips.dp.instrW != 32'b0) retired++;
            @(negedge clk);
        end
    endtask

    // Main check loop
    initial begin
        load_expected();
`ifdef FSDB
        $fsdbDumpfile({test, ".fsdb"});
        $fsdbDumpvars(0, testbench);
`else
        $dumpfile({test, ".vcd"});
        $dumpvars(0, testbench);
`endif
        reset = 1'b1;
        repeat (2) @(posedge clk);
        @(negedge clk) reset = 1'b0;
        fork count_perf(); join_none

        foreach (expected_addr[i]) begin
            do @(negedge clk); while (!memwrite);
            if (dataadr === expected_addr[i] && writedata === expected_data[i])
                $display("Memory write %0d successful : wrote %h to address %h",
                         i + 1, writedata, dataadr);
            else begin
                $display("ERROR: Memory write %0d : wrote %h to address %h ; Expected %h to address %h",
                         i + 1, writedata, dataadr, expected_data[i], expected_addr[i]);
                errors++;
            end
        end

        @(negedge clk); #1;  // last sw moves from Memory to Writeback
        $display("------------------------------------------------------------");
        $display("TEST %s : %s  (%0d errors)", test, errors ? "FAILED" : "PASSED", errors);
        $display("cycles = %0d, instructions = %0d, CPI = %.3f, IPC = %.3f",
                 cycles, retired, real'(cycles) / retired, real'(retired) / cycles);
        $display("TEST COMPLETE");
        $finish;
    end

    // Timeout watchdog
    initial begin
        #10000;
        $display("ERROR: TIMEOUT - not all expected memory writes happened");
        $finish;
    end
endmodule
