//////////////////////////////////////////////////////////////////////
// ===================================================================
// This file has the following module implementations:
// 1. datapath  - 5-stage pipelined MIPS datapath (+ hazard unit logic)
// 2. regfile   - 3-port register file (written on the FALLING edge)
// 3. alu       - ALU
// ===================================================================
//
// Pipeline: Fetch (F) -> Decode (D) -> Execute (E) -> Memory (M) -> Writeback (W)
// Signal naming: every signal carries its stage as a suffix (pcF, instrD, ...).
//
// Hazard handling (Harris & Harris, "Pipelined Processor", Sec. 7.5):
//   * Data hazards   : forwarding M->E and W->E  (forwardAE / forwardBE)
//                      forwarding M->D for the early branch compare
//                      (forwardAD / forwardBD)
//   * Load-use hazard: stall F/D one cycle, bubble into E (lwstall)
//   * Branch operand : stall if a beq in D needs a result still in E,
//                      or a load result still in M (branchstall)
//   * Control hazards: beq and j are resolved in Decode; the one wrong-path
//                      instruction in Fetch is flushed (flushD).
//
// Compile-time options (used only to measure the IPC benefit in the report):
//   +define+NO_FORWARDING : disable forwarding, stall on every RAW hazard
//   +define+NO_FLUSHING   : no predict-not-taken/flush; stall Fetch one cycle
//                           for every beq/j instead
//////////////////////////////////////////////////////////////////////
module datapath
    import mips_pkg::*;
(
    input  logic        clk, reset,
    // controller interface (Decode stage)
    output logic [5:0]  opD, functD,
    input  ctrl_t       ctrlD,
    // instruction memory (Fetch stage)
    output logic [31:0] pc,
    input  logic [31:0] instr,
    // data memory (Memory stage)
    output logic        memwrite,
    output logic [31:0] aluout, writedata,
    input  logic [31:0] readdata
);

    // ---------------------------------------------------------------
    // Signal declarations
    // ---------------------------------------------------------------
    // Fetch
    logic [31:0] pcF, pcnextF, pcplus4F, instrF;
    // Decode
    logic [31:0] instrD, pcplus4D, rd1D, rd2D, signimmD, pcbranchD, cmpaD, cmpbD;
    logic [4:0]  rsD, rtD, rdD;
    logic        equalD, pcsrcD;
    // Execute
    ctrl_t       ctrlE;
    logic [31:0] instrE, rd1E, rd2E, signimmE, srcaE, srcbE, writedataE, aluoutE;
    logic [4:0]  rsE, rtE, rdE, writeregE;
    // Memory
    ctrl_t       ctrlM;
    logic [31:0] instrM, aluoutM, writedataM, readdataM;
    logic [4:0]  writeregM;
    // Writeback
    logic        regwriteW, memtoregW;
    logic [31:0] instrW, aluoutW, readdataW, resultW;
    logic [4:0]  writeregW;
    // Hazard unit
    logic        stallF, stallD, flushD, flushE;
    logic        lwstallD, branchstallD, datastallD;
    logic        forwardAD, forwardBD;
    logic [1:0]  forwardAE, forwardBE;

    // RAW dependency check used by all forwarding/stall logic:
    // 'src' is read by a younger instruction, 'dst' is written by an older
    // one (we = its regwrite). $0 is never a real dependency.
    function automatic logic raw(input logic [4:0] src, dst, input logic we);
        return we && (src != 5'd0) && (src == dst);
    endfunction


    // ===============================================================
    // FETCH
    // ===============================================================
    // PC register: holds its value while the pipeline is stalled
    always_ff @(posedge clk, posedge reset)
        if (reset)        pcF <= '0;
        else if (!stallF) pcF <= pcnextF;

    assign pcplus4F = pcF + 32'd4;
    assign pc       = pcF;          // to instruction memory
    assign instrF   = instr;        // from instruction memory

    // Next PC: beq / j are resolved in Decode (predict not-taken)
    always_comb
        if (ctrlD.jump)  pcnextF = {pcplus4D[31:28], instrD[25:0], 2'b00};
        else if (pcsrcD) pcnextF = pcbranchD;
        else             pcnextF = pcplus4F;


    // ===============================================================
    // FETCH -> DECODE pipeline register (IF/ID)
    //   stallD: hold,  flushD: insert bubble (instr = 0 = NOP)
    // ===============================================================
    always_ff @(posedge clk, posedge reset)
        if (reset)        {instrD, pcplus4D} <= '0;
        else if (flushD)  {instrD, pcplus4D} <= '0;
        else if (!stallD) {instrD, pcplus4D} <= {instrF, pcplus4F};


    // ===============================================================
    // DECODE / REGISTER FILE
    // ===============================================================
    assign opD    = instrD[31:26];  // to controller
    assign functD = instrD[5:0];
    assign rsD    = instrD[25:21];
    assign rtD    = instrD[20:16];
    assign rdD    = instrD[15:11];

    // Register file: written in WB on the falling edge, so an instruction in
    // Decode reads the value written by WB in the same cycle.
    regfile rf (
        .clk (clk),
        .we3 (regwriteW), .wa3(writeregW), .wd3(resultW),
        .ra1 (rsD),       .rd1(rd1D),
        .ra2 (rtD),       .rd2(rd2D)
    );

    assign signimmD  = {{16{instrD[15]}}, instrD[15:0]};
    assign pcbranchD = pcplus4D + {signimmD[29:0], 2'b00};

    // Early branch resolution: compare operands in Decode.
    // Operands can be forwarded from the Memory stage (ALU result).
    assign cmpaD  = forwardAD ? aluoutM : rd1D;
    assign cmpbD  = forwardBD ? aluoutM : rd2D;
    assign equalD = (cmpaD == cmpbD);
    assign pcsrcD = ctrlD.branch & equalD;

    // ---------------- Hazard unit: stall / flush ----------------
    always_comb begin
`ifndef NO_FORWARDING
        // lw in E whose result is needed by the instruction in D
        lwstallD     = raw(rsD, writeregE, ctrlE.memtoreg) |
                       raw(rtD, writeregE, ctrlE.memtoreg);
        // beq in D needs a value still being computed in E,
        // or a load value that is only available at the end of M
        branchstallD = ctrlD.branch &
                       (raw(rsD, writeregE, ctrlE.regwrite) | raw(rtD, writeregE, ctrlE.regwrite) |
                        raw(rsD, writeregM, ctrlM.memtoreg) | raw(rtD, writeregM, ctrlM.memtoreg));
        datastallD   = 1'b0;
        forwardAD    = raw(rsD, writeregM, ctrlM.regwrite);
        forwardBD    = raw(rtD, writeregM, ctrlM.regwrite);
`else
        // No forwarding: wait until the producer reaches WB
        lwstallD     = 1'b0;
        branchstallD = 1'b0;
        datastallD   = raw(rsD, writeregE, ctrlE.regwrite) | raw(rtD, writeregE, ctrlE.regwrite) |
                       raw(rsD, writeregM, ctrlM.regwrite) | raw(rtD, writeregM, ctrlM.regwrite);
        forwardAD    = 1'b0;
        forwardBD    = 1'b0;
`endif
        stallD = lwstallD | branchstallD | datastallD;
        flushE = stallD;                    // bubble into Execute while D is held
`ifndef NO_FLUSHING
        stallF = stallD;
        // taken beq / j: squash the wrong-path instruction fetched after it
        flushD = (pcsrcD | ctrlD.jump) & ~stallD;
`else
        // Baseline without flushing: every beq/j costs one bubble.
        // Not-taken beq holds the PC so the next instruction is re-fetched.
        stallF = stallD | (ctrlD.branch & ~pcsrcD);
        flushD = (ctrlD.branch | ctrlD.jump) & ~stallD;
`endif
    end


    // ===============================================================
    // DECODE -> EXECUTE pipeline register (ID/EX)
    //   flushE: insert bubble (all control = 0)
    // ===============================================================
    always_ff @(posedge clk, posedge reset)
        if (reset)
            {ctrlE, instrE, rd1E, rd2E, signimmE, rsE, rtE, rdE} <= '0;
        else if (flushE)
            {ctrlE, instrE, rd1E, rd2E, signimmE, rsE, rtE, rdE} <= '0;
        else
            {ctrlE, instrE, rd1E, rd2E, signimmE, rsE, rtE, rdE} <=
            {ctrlD, instrD, rd1D, rd2D, signimmD, rsD, rtD, rdD};


    // ===============================================================
    // EXECUTE
    // ===============================================================
    // ---------------- Hazard unit: forwarding to E ----------------
    //   2'b10: from Memory stage (aluoutM), 2'b01: from Writeback (resultW)
    always_comb begin
        forwardAE = 2'b00;
        forwardBE = 2'b00;
`ifndef NO_FORWARDING
        if      (raw(rsE, writeregM, ctrlM.regwrite)) forwardAE = 2'b10;
        else if (raw(rsE, writeregW, regwriteW))      forwardAE = 2'b01;
        if      (raw(rtE, writeregM, ctrlM.regwrite)) forwardBE = 2'b10;
        else if (raw(rtE, writeregW, regwriteW))      forwardBE = 2'b01;
`endif
    end

    always_comb begin
        unique case (forwardAE)
            2'b10:   srcaE = aluoutM;
            2'b01:   srcaE = resultW;
            default: srcaE = rd1E;
        endcase
        unique case (forwardBE)
            2'b10:   writedataE = aluoutM;
            2'b01:   writedataE = resultW;
            default: writedataE = rd2E;
        endcase
    end

    assign srcbE     = ctrlE.alusrc ? signimmE : writedataE;
    assign writeregE = ctrlE.regdst ? rdE : rtE;

    alu alu (
        .a      (srcaE),
        .b      (srcbE),
        .control(ctrlE.alucontrol),
        .result (aluoutE),
        .zero   ()                  // unused: beq is resolved in Decode
    );


    // ===============================================================
    // EXECUTE -> MEMORY pipeline register (EX/MEM)
    // ===============================================================
    always_ff @(posedge clk, posedge reset)
        if (reset) {ctrlM, instrM, aluoutM, writedataM, writeregM} <= '0;
        else       {ctrlM, instrM, aluoutM, writedataM, writeregM} <=
                   {ctrlE, instrE, aluoutE, writedataE, writeregE};


    // ===============================================================
    // MEMORY  (data memory lives in 'top'; these are its ports)
    // ===============================================================
    assign memwrite  = ctrlM.memwrite;
    assign aluout    = aluoutM;         // data memory address
    assign writedata = writedataM;
    assign readdataM = readdata;


    // ===============================================================
    // MEMORY -> WRITEBACK pipeline register (MEM/WB)
    // ===============================================================
    always_ff @(posedge clk, posedge reset)
        if (reset) {regwriteW, memtoregW, instrW, aluoutW, readdataW, writeregW} <= '0;
        else       {regwriteW, memtoregW, instrW, aluoutW, readdataW, writeregW} <=
                   {ctrlM.regwrite, ctrlM.memtoreg, instrM, aluoutM, readdataM, writeregM};


    // ===============================================================
    // WRITEBACK
    // ===============================================================
    assign resultW = memtoregW ? readdataW : aluoutW;

endmodule


//////////////////////////////////////////////////////////////////////
// Register File Module
//  - two combinational read ports, one write port
//  - written on the FALLING edge of clk (pipelined version): WB writes in
//    the first half of the cycle, Decode reads in the second half, so no
//    extra WB->D forwarding path is needed.
//  - register 0 hardwired to 0
//////////////////////////////////////////////////////////////////////
module regfile (
    input  logic        clk,
    input  logic        we3,
    input  logic [4:0]  ra1, ra2, wa3,
    input  logic [31:0] wd3,
    output logic [31:0] rd1, rd2
);
    logic [31:0] rf [31:0];

    always_ff @(negedge clk)
        if (we3) rf[wa3] <= wd3;

    assign rd1 = (ra1 != 0) ? rf[ra1] : '0;
    assign rd2 = (ra2 != 0) ? rf[ra2] : '0;
endmodule


//////////////////////////////////////////////////////////////////////
// ALU Module (unchanged behaviour, SystemVerilog syntax)
//////////////////////////////////////////////////////////////////////
module alu
    import mips_pkg::*;
(
    input  logic [31:0] a,          // First operand
    input  logic [31:0] b,          // Second operand
    input  logic [2:0]  control,    // ALU control signal
    output logic [31:0] result,     // ALU result
    output logic        zero        // Zero flag
);
    always_comb
        unique case (control)
            ALU_AND: result = a & b;
            ALU_OR:  result = a | b;
            ALU_ADD: result = a + b;
            ALU_SUB: result = a - b;
            ALU_SLT: result = {31'b0, $signed(a) < $signed(b)};
            default: result = 'x;                       // undefined operation
        endcase

    assign zero = (result == '0);
endmodule
