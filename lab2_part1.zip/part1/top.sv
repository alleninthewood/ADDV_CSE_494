////////////////////////////////////////////////////////////////////////////
// ========================================================================
// This file has the following module implementations:
// 1. top
// 2. mips
// 3. dmem
// 4. imem
// =========================================================================
////////////////////////////////////////////////////////////////////////////
import mips_pkg::*;

////////////////////////////////////////////////////////////////////////////
// Top Module  (interface UNCHANGED from the original design)
//  - connects the MIPS processor to instruction and data memory
//  - writedata / dataadr / memwrite now come from the Memory stage
////////////////////////////////////////////////////////////////////////////
module top (
    input  logic        clk, reset,
    output logic [31:0] writedata, dataadr,
    output logic        memwrite
);
    logic [31:0] pc, instr, readdata;

    // instantiate processor and memories
    mips mips (clk, reset, pc, instr, memwrite, dataadr, writedata, readdata);
    imem imem (pc[7:2], instr);
    dmem dmem (clk, memwrite, dataadr, writedata, readdata);
endmodule


//////////////////////////////////////////////////////////////////////
// 5-stage Pipelined MIPS Processor Module (ports UNCHANGED)
//  - controller decodes the instruction in the Decode stage
//    (opD/functD come from the IF/ID register inside the datapath)
//  - all pipeline registers and hazard logic live in the datapath
//////////////////////////////////////////////////////////////////////
module mips (
    input  logic        clk, reset,
    output logic [31:0] pc,
    input  logic [31:0] instr,
    output logic        memwrite,
    output logic [31:0] aluout, writedata,
    input  logic [31:0] readdata
);
    logic [5:0] opD, functD;
    ctrl_t      ctrlD;

    controller c  (.*);     // .* : connect ports to same-named signals
    datapath   dp (.*);
endmodule


//////////////////////////////////////////////////////////////////////
// Data Memory Module (64 words, combinational read, write on posedge)
//////////////////////////////////////////////////////////////////////
module dmem (
    input  logic        clk, we,
    input  logic [31:0] a, wd,
    output logic [31:0] rd
);
    logic [31:0] RAM [63:0];

    assign rd = RAM[a[31:2]];   // word aligned

    always_ff @(posedge clk)
        if (we) RAM[a[31:2]] <= wd;
endmodule


//////////////////////////////////////////////////////////////////////
// Instruction Memory Module (64 words, combinational read)
//  - loads memfile.dat by default
//  - a different program can be selected at run time with
//    +TEST=<name>  ->  loads <name>.dat   (e.g. ./simv +TEST=fwd_test)
//////////////////////////////////////////////////////////////////////
module imem (
    input  logic [5:0]  a,
    output logic [31:0] rd
);
    logic [31:0] RAM [63:0];

`ifndef SYNTHESIS   // simulation-only program loading (DC defines SYNTHESIS)
    string test;
    initial begin
        if (!$value$plusargs("TEST=%s", test)) test = "memfile";
        $readmemh({test, ".dat"}, RAM);
    end
`endif

    assign rd = RAM[a];         // word aligned
endmodule
