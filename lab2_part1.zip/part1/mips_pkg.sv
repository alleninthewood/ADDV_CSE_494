//////////////////////////////////////////////////////////////////////
// mips_pkg
//  - Shared types/constants for the 5-stage pipelined MIPS processor.
//  - ctrl_t bundles every control signal produced by the controller in
//    the Decode stage, so a whole stage's control can be moved through a
//    pipeline register with a single assignment (ctrlE <= ctrlD).
//////////////////////////////////////////////////////////////////////
package mips_pkg;

    // Opcodes (instr[31:26])
    localparam logic [5:0] OP_RTYPE = 6'b000000;
    localparam logic [5:0] OP_LW    = 6'b100011;
    localparam logic [5:0] OP_SW    = 6'b101011;
    localparam logic [5:0] OP_BEQ   = 6'b000100;
    localparam logic [5:0] OP_ADDI  = 6'b001000;
    localparam logic [5:0] OP_J     = 6'b000010;

    // ALU control codes (same encoding as the original design)
    localparam logic [2:0] ALU_AND = 3'b000;
    localparam logic [2:0] ALU_OR  = 3'b001;
    localparam logic [2:0] ALU_ADD = 3'b010;
    localparam logic [2:0] ALU_SUB = 3'b110;
    localparam logic [2:0] ALU_SLT = 3'b111;

    // Control word generated in Decode
    typedef struct packed {
        logic       regwrite;    // write register file in WB
        logic       memtoreg;    // WB result comes from data memory (lw)
        logic       memwrite;    // write data memory in MEM (sw)
        logic       branch;      // beq (resolved in Decode)
        logic       alusrc;      // ALU srcB = sign-extended immediate
        logic       regdst;      // destination register = rd (R-type)
        logic       jump;        // j (resolved in Decode)
        logic [2:0] alucontrol;  // ALU operation
    } ctrl_t;

endpackage
