# Lab 2 – Part 1: 5-Stage Pipelined MIPS (SystemVerilog)

## Files
| File | Description |
|---|---|
| `mips_pkg.sv` | opcodes, ALU codes, `ctrl_t` control-word struct |
| `controller.sv` | Decode-stage main + ALU decoder (combinational) |
| `datapath.sv` | 5-stage datapath: Fetch → IF/ID → Decode → ID/EX → Execute → EX/MEM → Memory → MEM/WB → Writeback, hazard unit (forwarding / stall / flush), `regfile`, `alu` |
| `top.sv` | `top`, `mips`, `imem`, `dmem` (top-level interface unchanged) |
| `testbench.sv` | checks every data-memory write, reports CPI / IPC |
| `*.txt` / `*.dat` | MIPS assembly / machine code (`asm.py` converts .txt → .dat) |
| `asm.py` | tiny assembler for the supported instructions |

Hierarchy: `testbench → top → {mips → {controller, datapath}, imem, dmem}`

## Test programs
| `+TEST=` | Purpose |
|---|---|
| `memfile` (default) | every instruction: add, sub, and, or, slt, lw, sw, beq, (+addi, j) |
| `fwd_test` | back-to-back ADD data hazards → forwarding (0 stalls) |
| `branch_test` | taken / not-taken / backward BEQ → flushing |
| `original` | original program given with the lab |

## How to run (Apporto, VCS + Verdi)
```bash
make                        # assemble + run all tests
make sim TEST=fwd_test      # one test, writes fwd_test.fsdb + fwd_test.log
make verdi TEST=fwd_test    # view waveform
make perf                   # IPC with vs. without forwarding / flushing
make clean
```
If FSDB dumping is not available: `make sim TEST=fwd_test FSDB=0` (writes `fwd_test.vcd`).

Icarus Verilog (optional): `iverilog -g2012 -o simv mips_pkg.sv controller.sv datapath.sv top.sv testbench.sv && vvp simv +TEST=memfile`

## Compile-time options (for the performance comparison only)
- `+define+NO_FORWARDING` – no forwarding; stall on every RAW hazard
- `+define+NO_FLUSHING` – no predict-not-taken/flush; every beq/j costs one bubble
