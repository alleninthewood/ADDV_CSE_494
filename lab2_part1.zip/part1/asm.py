#!/usr/bin/env python3
"""Tiny MIPS assembler for the Lab 2 instruction subset.

Usage:  python3 asm.py program.txt program.dat

Supports: add sub and or slt (R-type), addi, lw, sw, beq, j
Syntax:   one instruction per line, '#' comments, 'label:' prefixes,
          registers as $0..$31, immediates in decimal or 0x hex.
"""
import re
import sys

RTYPE = {"add": 0x20, "sub": 0x22, "and": 0x24, "or": 0x25, "slt": 0x2A}
OPC = {"addi": 0x08, "lw": 0x23, "sw": 0x2B, "beq": 0x04, "j": 0x02}


def reg(tok):
    return int(tok.strip().lstrip("$"))


def num(tok):
    return int(tok.strip(), 0)


def assemble(lines):
    # pass 1: strip comments, collect labels
    prog, labels = [], {}
    for line in lines:
        line = line.split("#")[0].strip()
        while ":" in line:
            lab, line = line.split(":", 1)
            labels[lab.strip()] = len(prog)
            line = line.strip()
        if line:
            prog.append(line)

    # pass 2: encode
    words = []
    for pc, line in enumerate(prog):
        op, _, rest = line.partition(" ")
        args = [a.strip() for a in rest.split(",")] if rest else []
        if op in RTYPE:                                   # rd, rs, rt
            rd, rs, rt = map(reg, args)
            w = (rs << 21) | (rt << 16) | (rd << 11) | RTYPE[op]
        elif op == "addi":                                # rt, rs, imm
            rt, rs, imm = reg(args[0]), reg(args[1]), num(args[2])
            w = (OPC[op] << 26) | (rs << 21) | (rt << 16) | (imm & 0xFFFF)
        elif op in ("lw", "sw"):                          # rt, imm(rs)
            m = re.fullmatch(r"(.+)\((\$\d+)\)", args[1])
            rt, imm, rs = reg(args[0]), num(m.group(1)), reg(m.group(2))
            w = (OPC[op] << 26) | (rs << 21) | (rt << 16) | (imm & 0xFFFF)
        elif op == "beq":                                 # rs, rt, label
            rs, rt = reg(args[0]), reg(args[1])
            off = labels[args[2]] - (pc + 1)
            w = (OPC[op] << 26) | (rs << 21) | (rt << 16) | (off & 0xFFFF)
        elif op == "j":                                   # label
            w = (OPC[op] << 26) | labels[args[0]]
        else:
            raise SystemExit(f"line {pc}: unknown instruction '{line}'")
        words.append(w)
    return words


if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    with open(src) as f:
        words = assemble(f.readlines())
    with open(dst, "w") as f:
        f.write("\n".join(f"{w:08x}" for w in words) + "\n")
    print(f"{src}: {len(words)} instructions -> {dst}")
