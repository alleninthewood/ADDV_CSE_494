//////////////////////////////////////////////////////////////////////
// Controller (Decode stage)
//  - Purely combinational: decodes the instruction sitting in the
//    Decode stage (opD/functD) into a ctrl_t control word.
//  - Combines the original maindec + aludec into one always_comb.
//  - Changes from the single-cycle version:
//      * No 'zero' input / 'pcsrc' output any more: beq is resolved in
//        the Decode stage of the datapath (equalD & branch).
//      * Control signals are pipelined inside the datapath
//        (ctrlD -> ctrlE -> ctrlM -> W) instead of being used directly.
//      * Unknown opcodes decode to all-zero control (behaves as a NOP).
//////////////////////////////////////////////////////////////////////
module controller
    import mips_pkg::*;
(
    input  logic [5:0] opD,     // instrD[31:26]
    input  logic [5:0] functD,  // instrD[5:0]
    output ctrl_t      ctrlD    // control word for the Decode-stage instruction
);
    logic [1:0] aluop;          // 00: add, 01: sub, 10: use funct

    always_comb begin
        // ---------------- main decoder ----------------
        ctrlD = '0;
        aluop = 2'b00;
        unique case (opD)
            OP_RTYPE: begin ctrlD.regwrite = 1'b1; ctrlD.regdst = 1'b1; aluop = 2'b10; end
            OP_LW:    begin ctrlD.regwrite = 1'b1; ctrlD.alusrc = 1'b1; ctrlD.memtoreg = 1'b1; end
            OP_SW:    begin ctrlD.alusrc   = 1'b1; ctrlD.memwrite = 1'b1; end
            OP_BEQ:   begin ctrlD.branch   = 1'b1; aluop = 2'b01; end
            OP_ADDI:  begin ctrlD.regwrite = 1'b1; ctrlD.alusrc = 1'b1; end
            OP_J:     begin ctrlD.jump     = 1'b1; end
            default:  ;                                     // illegal op -> NOP
        endcase

        // ---------------- ALU decoder -----------------
        unique case (aluop)
            2'b00:   ctrlD.alucontrol = ALU_ADD;            // lw / sw / addi
            2'b01:   ctrlD.alucontrol = ALU_SUB;            // beq
            default: unique case (functD)                   // R-type
                // 0x00000000 = "sll $0,$0,0" = canonical MIPS NOP. Pipeline
                // bubbles (flush/stall/reset) are all-zero instructions, so
                // decode them as a clean NOP (no register write, no X's).
                6'b000000: begin ctrlD.regwrite = 1'b0; ctrlD.alucontrol = ALU_ADD; end
                6'b100000: ctrlD.alucontrol = ALU_ADD;
                6'b100010: ctrlD.alucontrol = ALU_SUB;
                6'b100100: ctrlD.alucontrol = ALU_AND;
                6'b100101: ctrlD.alucontrol = ALU_OR;
                6'b101010: ctrlD.alucontrol = ALU_SLT;
                default:   ctrlD.alucontrol = 3'bxxx;       // unsupported funct
            endcase
        endcase
    end
endmodule
