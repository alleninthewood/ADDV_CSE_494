`timescale 1ns/1ps

module tb_even_odd_alternator;
    localparam int DATA_WIDTH = 8;
    localparam int ADDR_WIDTH = 6;
    localparam int ITEMS = 80;

    // 1. Clock and signal declarations
    logic Clock = 0;
    always #5 Clock = ~Clock;  // 10ns period (100MHz)

    logic Reset = 1;
    logic [DATA_WIDTH-1:0] Data_in = '0;
    logic Write_en = 0;
    logic Read_en = 0;
    logic [DATA_WIDTH-1:0] Data_out;

    // 2. DUT (Design Under Test) instantiation
    even_odd_alternator #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH)
    ) dut (
        .Clock(Clock),
        .Reset(Reset),
        .Data_in(Data_in),
        .Write_en(Write_en),
        .Read_en(Read_en),
        .Data_out(Data_out)
    );

// 3. Scoreboard variables and queue declarations
    logic [DATA_WIDTH-1:0] expected_even[$];
    logic [DATA_WIDTH-1:0] expected_odd[$];
    bit expect_even;

    // 4. Self-checking scoreboard
    always @(posedge Clock) begin
        bit pop_now;
        logic [DATA_WIDTH-1:0] expected;

        if (!Reset) begin
            pop_now = dut.pop;

            // Step 1. On DUT read (pop), fetch expected value based on current parity turn
            if (pop_now) begin
                if (expect_even) begin
                    if (expected_even.size() == 0)
                        $fatal(1, "Unexpected even output!");
                    expected = expected_even.pop_front();
                end else begin
                    if (expected_odd.size() == 0)
                        $fatal(1, "Unexpected odd output!");
                    expected = expected_odd.pop_front();
                end

                // Toggle parity turn flag (even <-> odd)
                expect_even = !expect_even;
            end

            // Step 2. Record input written in current cycle (Write_en) to scoreboard queue
            if (Write_en) begin
                if (Data_in[0]) // LSB is 1 -> Odd
                    expected_odd.push_back(Data_in);
                else            // LSB is 0 -> Even
                    expected_even.push_back(Data_in);
            end

            // Step 3. Wait for register updates (#1 delay) and verify DUT output
            if (pop_now) begin
                #1;
                if (Data_out !== expected)
                    $fatal(1, "Mismatch! Expected %0d, got %0d", expected, Data_out);
            end
        end
    end

    // 5. Test case execution scenario (Task)
    task automatic run_case(input bit odd_first);
        logic [DATA_WIDTH-1:0] value;
        int index;

        // Reset scoreboard state
        expected_even.delete();
        expected_odd.delete();
        expect_even = 1'b1;

        // Hardware reset DUT
        @(negedge Clock);
        Reset = 1;
        Write_en = 0;
        Read_en = 0;
        Data_in = '0;

        repeat (4) @(negedge Clock);
        Reset = 0;
        repeat (3) @(posedge Clock);
        #1;

        if (Data_out !== '0)
            $fatal(1, "Data_out did not reset to zero");

        // [Phase 1] Transmit inputs over 100 cycles (push 80 items & 80% read request rate)
        for (int cycle = 0; cycle < 100; cycle++) begin
            @(negedge Clock);

            // Write data for 80 out of 100 clock cycles
            if (cycle < ITEMS) begin
                Write_en = 1'b1;
                index = cycle % 40;

                // Generate worst-case pattern (unbalanced input stream of 40 consecutive items)
                if ((cycle < 40) == odd_first)
                    Data_in = DATA_WIDTH'(2 * index + 1); // Generate odd number
                else
                    Data_in = DATA_WIDTH'(2 * index + 2); // Generate even number
            end else begin
                Write_en = 1'b0;
                Data_in = '0;
            end

            // Issue read request (Read_en) at 8-in-10 clock cycle rate
            Read_en = ((cycle % 10) < 8) ? 1'b1 : 1'b0;
        end

        // [Phase 2] Continue reading after stopping writes until remaining data is fully drained
        for (int cycle = 100; cycle < 400; cycle++) begin
            if (expected_even.size() == 0 && expected_odd.size() == 0) break;

            @(negedge Clock);
            Write_en = 1'b0;
            Data_in = '0;
            Read_en = ((cycle % 10) < 8) ? 1'b1 : 1'b0;
        end

        // Verify that all expected data has been drained from scoreboard queues
        if (expected_even.size() != 0 || expected_odd.size() != 0) begin
            $fatal(1, "Data remaining in scoreboard! even_left=%0d, odd_left=%0d",
                   expected_even.size(), expected_odd.size());
        end

        $display("PASS: %s-first pattern test completed successfully!",
                 odd_first ? "Odd" : "Even");
    endtask

    // 6. Main simulation execution block
    initial begin
`ifdef VERDI
        $fsdbDumpfile("tb_even_odd_alternator.fsdb");
        $fsdbDumpvars(0, tb_even_odd_alternator);
`endif

        $display("--- Starting Testcase 1: 40 Odd then 40 Even ---");
        run_case(1'b1); // 40 Odd then 40 Even

        $display("--- Starting Testcase 2: 40 Even then 40 Odd ---");
        run_case(1'b0); // 40 Even then 40 Odd

        $display("========================================");
        $display("ALL TESTS PASSED SUCCESSFULLY!");
        $display("========================================");
        $finish;
    end

    // 7. Timeout guard against infinite loops
    initial begin
        #100000;
        $fatal(1, "Testbench timeout forced termination");
    end
endmodule