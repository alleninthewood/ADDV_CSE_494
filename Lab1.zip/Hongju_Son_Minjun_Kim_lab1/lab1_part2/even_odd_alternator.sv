// ============================================================================
// even_odd_alternator.sv  (Lab #1, Part II)
//
// Takes a single input stream that mixes even and odd 8-bit numbers in an
// arbitrary order, and re-emits them so the output strictly alternates
// even, odd, even, odd, ... while preserving each number's original
// relative order within its own parity.
//
// Design: demux writes into two FIFOs by parity (write side is pure
// combinational logic), then a 2-state FSM on the read side pops
// alternately from whichever FIFO is "due" next, pausing (not outputting
// anything new) whenever that FIFO has nothing to give it yet.
//
// Reuses the verified fifo1 IP from Part I as a plain synchronous FIFO by
// driving both its write clock and read clock from the single system Clock
// -- no need to design a second FIFO from scratch, and no points are lost
// either way per the lab spec. fifo1's wfull is intentionally not used to
// back-pressure writes; instead ADDR_WIDTH is sized (see README) so the
// guaranteed 80-writes/100-cycle rate can never overflow it.
// ============================================================================
`timescale 1ns/1ps

module even_odd_alternator #(
    parameter int DATA_WIDTH = 8,
    parameter int ADDR_WIDTH = 6     // per-FIFO depth = 2**ADDR_WIDTH; see
                                      // README for how this was sized
)(
    input  logic                  Clock,
    input  logic                  Reset,     // active-high, per lab I/O table
    input  logic [DATA_WIDTH-1:0] Data_in,
    input  logic                  Write_en,
    output logic [DATA_WIDTH-1:0] Data_out,
    input  logic                  Read_en
);

    logic rst_n;
    assign rst_n = ~Reset;

    // ---- write side: purely combinational demux by parity -----------------
    // Data_in[0]==0 -> even -> even FIFO, Data_in[0]==1 -> odd -> odd FIFO.
    logic even_winc, odd_winc;
    logic even_wfull, odd_wfull;
    assign even_winc = Write_en && !Data_in[0];
    assign odd_winc  = Write_en &&  Data_in[0];

    // ---- read side signals, driven by the FSM below ------------------------
    logic even_rinc, odd_rinc;
    logic even_rempty, odd_rempty;
    logic [DATA_WIDTH-1:0] even_rdata, odd_rdata;

    fifo1 #(.DSIZE(DATA_WIDTH), .ASIZE(ADDR_WIDTH)) u_even_fifo (
        .rdata        (even_rdata),
        .wfull        (even_wfull),
        .rempty       (even_rempty),
        .almost_full  (),
        .almost_empty (),
        .wdata        (Data_in),
        .winc         (even_winc),
        .wclk         (Clock),
        .wrst_n       (rst_n),
        .rinc         (even_rinc),
        .rclk         (Clock),
        .rrst_n       (rst_n)
    );

    fifo1 #(.DSIZE(DATA_WIDTH), .ASIZE(ADDR_WIDTH)) u_odd_fifo (
        .rdata        (odd_rdata),
        .wfull        (odd_wfull),
        .rempty       (odd_rempty),
        .almost_full  (),
        .almost_empty (),
        .wdata        (Data_in),
        .winc         (odd_winc),
        .wclk         (Clock),
        .wrst_n       (rst_n),
        .rinc         (odd_rinc),
        .rclk         (Clock),
        .rrst_n       (rst_n)
    );

    // ---- read side: 2-state FSM enforcing strict alternation --------------
    typedef enum logic { WANT_EVEN, WANT_ODD } state_t;
    state_t state;

    logic                  want_empty;
    logic [DATA_WIDTH-1:0] want_data;
    logic                  pop;

    assign want_empty = (state == WANT_EVEN) ? even_rempty : odd_rempty;
    assign want_data  = (state == WANT_EVEN) ? even_rdata  : odd_rdata;

    // pause (produce nothing) instead of a bogus 0 whenever the parity
    // that's due next isn't available yet
    assign pop = Read_en && !want_empty;

    assign even_rinc = pop && (state == WANT_EVEN);
    assign odd_rinc  = pop && (state == WANT_ODD);

    always_ff @(posedge Clock or negedge rst_n) begin
        if (!rst_n) begin
            state    <= WANT_EVEN;
            Data_out <= '0;
        end else if (pop) begin
            Data_out <= want_data;
            state    <= (state == WANT_EVEN) ? WANT_ODD : WANT_EVEN;
        end
        // else: hold Data_out and state -- this is the "pause" behavior
    end

endmodule
