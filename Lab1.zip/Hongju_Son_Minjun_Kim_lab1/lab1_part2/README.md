# Lab 1 — Part II: Even/Odd FIFO Alternator

This SystemVerilog design accepts a stream of 8-bit values, stores even and odd values in separate FIFOs, and reads them in even, odd, even, odd order. The order of values within each parity is preserved. If the FIFO for the parity due next is empty, the output holds its previous value until a read can occur.

## Project structure

```text
lab1_part2/
├── even_odd_alternator.sv     # Parity demultiplexer and alternating-read FSM
├── rtl/
│   └── fifo1.sv              # Part I FIFO and its supporting modules
├── tb_even_odd_alternator.sv # Self-checking Part II testbench
├── sim/
│   └── Makefile              # VCS and Verdi targets
└── env.cshrc                 # Course tool environment
```

The alternator instantiates two `fifo1` modules. It drives both the write and read clocks of each FIFO with `Clock`. `Reset` is active high at the alternator's interface and is inverted for the FIFO's active-low reset inputs.

## Operation

- When `Write_en` is high, `Data_in[0]` routes the value to the even FIFO (`0`) or odd FIFO (`1`).
- After reset, the read FSM expects an even value. On a clock edge with `Read_en` high and the expected FIFO nonempty, it reads that FIFO, updates `Data_out`, and changes the expected parity.
- When the expected FIFO is empty or `Read_en` is low, the FSM and `Data_out` hold their values. `Data_out` has no separate valid output; an unchanged value does not indicate a new output item.

## FIFO depth and supported workload

`ADDR_WIDTH = 6` gives each FIFO `2^6 = 64` entries. The two directed test cases each write 40 even and 40 odd values, so either FIFO holds at most 40 values even if reading is delayed. The 64-entry choice is sufficient for those cases.

This depth does **not** guarantee lossless operation for an arbitrary stream of 80 values: all 80 could have the same parity, while the read FSM waits for the other parity. The current design does not use `wfull` to stop or report writes. A bounded, arbitrary 80-value burst needs at least 80 entries per FIFO (for example, `ADDR_WIDTH = 7` gives 128). An unbounded stream additionally needs backpressure, error handling, or a stated input constraint.

## Run the simulation

Use the course VCS environment and a `tcsh` terminal:

```tcsh
cd lab1_part2
source env.cshrc
cd sim
make compile_and_sim
```

The Makefile compiles `../even_odd_alternator.sv`, `../rtl/fifo1.sv`, and `../tb_even_odd_alternator.sv`. The testbench runs a 40-odd-then-40-even case and a 40-even-then-40-odd case. A successful run ends with:

```text
PASS:  Odd-first pattern test completed successfully!
PASS: Even-first pattern test completed successfully!
ALL TESTS PASSED SUCCESSFULLY!
```

The testbench's separate expected-even and expected-odd queues check output order and values when the DUT pops an item. These two cases do not cover every possible input sequence.

## View waveforms

From `lab1_part2/sim`, after loading `env.cshrc`:

```tcsh
make compile_verdi
make sim
make waves_verdi
```

`compile_verdi` enables the testbench's `VERDI` conditional dump. `make sim` produces `tb_even_odd_alternator.fsdb`, and `make waves_verdi` opens it in Verdi. For report screenshots, select a short interval and show the input, output, enables, parity write/read controls, and read FSM state. Annotate the input routing and alternating reads.

To remove generated simulation files, run `make clean` from the `sim` directory.
