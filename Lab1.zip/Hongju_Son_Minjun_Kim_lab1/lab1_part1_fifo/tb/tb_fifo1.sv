// ============================================================================
// tb_fifo1.sv
//
// Plain Verilog-style self-checking testbench (no classes / UVM) for the
// fifo1-based skeleton (rtl/fifo1.sv). Same three scenarios as before, just
// driving fifo1's flat ports directly instead of going through an interface
// handshake:
//   1) empty -> fill -> full -> drain -> empty
//   2) almost_full / almost_empty assert at the right occupancy
//   3) simultaneous, free-running read & write at two different clock rates
// ============================================================================
`timescale 1ns/1ps

module tb_fifo1;

    localparam int DSIZE = 8;
    localparam int ASIZE = 4;
    localparam int DEPTH = 1 << ASIZE;   // 16

    // write clock: 10ns period (100MHz). read clock: 8.5ns half-period
    // (~58.8MHz) -- deliberately not an integer multiple of the write clock
    // so the two domains are genuinely asynchronous to one another.
    logic wclk = 0;
    logic rclk = 0;
    always #5   wclk = ~wclk;
    always #8.5 rclk = ~rclk;

    logic              wrst_n, rrst_n;
    logic              winc, rinc;
    logic [DSIZE-1:0]  wdata;
    logic [DSIZE-1:0]  rdata;
    logic              wfull, rempty;
    logic              almost_full, almost_empty;

    fifo1 #(.DSIZE(DSIZE), .ASIZE(ASIZE)) dut (
        .rdata        (rdata),
        .wfull        (wfull),
        .rempty       (rempty),
        .almost_full  (almost_full),
        .almost_empty (almost_empty),
        .wdata        (wdata),
        .winc         (winc),
        .wclk         (wclk),
        .wrst_n       (wrst_n),
        .rinc         (rinc),
        .rclk         (rclk),
        .rrst_n       (rrst_n)
    );

    // ---- reference model ----------------------------------------------
    logic [DSIZE-1:0] ref_q[$];
    int errors = 0;

    task automatic wr_push(input logic [DSIZE-1:0] d);
        bit accepted;
        @(posedge wclk);              // edge A
        wdata    <= d;
        winc     <= 1'b1;
        #1;                           // let edge A's own registered updates
                                       // settle; wfull now correctly reflects
                                       // "full going into the write that is
                                       // about to happen on the NEXT edge"
        accepted = !wfull;
        @(posedge wclk);              // edge B -- the write itself happens here
        #1;                           // let edge B's registered updates (wbin,
                                       // wfull) settle before returning, so
                                       // code right after wr_push() (or the
                                       // next wr_push call) doesn't race it
        winc     <= 1'b0;
        if (accepted) ref_q.push_back(d);   // model only what was actually accepted
    endtask

    task automatic rd_pop();
        logic [DSIZE-1:0] expected;
        bit had_data;
        @(posedge rclk);              // edge A
        rinc <= 1'b1;
        #1;                           // let edge A's own registered updates
                                       // (rempty, rbin/raddr/rdata) settle.
                                       // rempty/rdata are registers in the
                                       // rclk domain, so they can only change
                                       // AT an rclk edge and hold constant
                                       // until the next one -- sampling them
                                       // here gives exactly the value edge B
                                       // (the real read) will use. Checking
                                       // at task ENTRY instead (before edge A)
                                       // can miss an update landing exactly on
                                       // edge A -- that caused a growing-offset
                                       // drift during concurrent read/write.
        had_data = (ref_q.size() > 0) && !rempty;
        if (had_data) begin
            expected = ref_q.pop_front();
            if (rdata !== expected) begin
                $display("[%0t] ERROR: expected %0d, got %0d", $time, expected, rdata);
                errors++;
            end
        end
        @(posedge rclk);              // edge B -- the read itself happens here
        #1;                           // let edge B's registered updates settle
                                       // before returning
        rinc <= 1'b0;
    endtask

    initial begin
`ifdef VERDI
        $fsdbDumpfile("tb_fifo1.fsdb");
        $fsdbDumpvars(0, tb_fifo1);
`else
        $dumpfile("tb_fifo1.vcd");
        $dumpvars(0, tb_fifo1);
`endif

        wrst_n = 0; winc = 0; wdata = '0;
        rrst_n = 0; rinc = 0;
        repeat (3) @(posedge wclk);
        wrst_n = 1;
        repeat (3) @(posedge rclk);
        rrst_n = 1;
        repeat (2) @(posedge wclk);

        // ------------------------------------------------------------
        // Scenario 1: empty -> fill -> full, and almost_full assertion
        // ------------------------------------------------------------
        if (!rempty) begin
            $display("ERROR: FIFO not empty after reset"); errors++;
        end

        for (int i = 0; i < DEPTH; i++) begin
            wr_push(i[DSIZE-1:0]);
            if (i == (DEPTH*3/4 - 1)) begin
                #1;
                if (!almost_full) begin
                    $display("ERROR: almost_full not set at %0d/%0d words", i+1, DEPTH);
                    errors++;
                end
            end
        end

        if (!wfull) begin
            $display("ERROR: FIFO not full after %0d writes", DEPTH); errors++;
        end

        // attempted overflow write must be silently dropped, not corrupt data
        wr_push(8'hFF);

        // ------------------------------------------------------------
        // Scenario 1 (cont'd): full -> drain -> empty, almost_empty check
        // ------------------------------------------------------------
        for (int i = 0; i < DEPTH; i++) begin
            rd_pop();
            if (i == (DEPTH - DEPTH/4 - 1)) begin
                #1;
                if (!almost_empty) begin
                    $display("ERROR: almost_empty not set with %0d words left", DEPTH/4);
                    errors++;
                end
            end
        end

        @(posedge rclk); #1;
        if (!rempty) begin
            $display("ERROR: FIFO not empty after draining"); errors++;
        end

        // ------------------------------------------------------------
        // Scenario 2: simultaneous read & write, different clock rates
        // ------------------------------------------------------------
        fork
            begin : writer
                for (int i = 0; i < 300; i++) wr_push(i[DSIZE-1:0]);
            end
            begin : reader
                for (int i = 0; i < 300; i++) rd_pop();
            end
        join

        repeat (5) @(posedge rclk);
        if (errors == 0) $display("TB_FIFO1: ALL TESTS PASSED");
        else              $display("TB_FIFO1: %0d ERROR(S)", errors);
        $finish;
    end

endmodule
