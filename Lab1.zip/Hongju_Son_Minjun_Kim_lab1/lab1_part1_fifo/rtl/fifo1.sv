// ============================================================================
// fifo1.sv -- async FIFO, based on the professor-approved reference skeleton.
//
// Only two things were added on top of the original skeleton, to satisfy the
// lab's SystemVerilog requirements:
//   1) interface + modport, used in the MEMORY BLOCK (fifo_mem_if / fifomem)
//   2) `.*` implicit port connections, used for every submodule instance
//      whose local signal names already match the submodule's port names
//      one-for-one (they do, by construction, for wptr_full / rptr_empty /
//      sync_r2w / sync_w2r / fifomem)
// No pointer/Gray-code/full-empty logic was changed.
// ============================================================================

// ---------------------------------------------------------------------------
// Interface for the memory block. Bundles fifomem's 7 signals so fifomem can
// be connected through a single modport port instead of a flat port list.
// ---------------------------------------------------------------------------
interface fifo_mem_if #(parameter DATASIZE = 8, parameter ADDRSIZE = 4);
    logic [DATASIZE-1:0] wdata;
    logic [DATASIZE-1:0] rdata;
    logic [ADDRSIZE-1:0] waddr;
    logic [ADDRSIZE-1:0] raddr;
    logic                wclken;
    logic                wfull;
    logic                wclk;

    // fifomem's own view: everything but rdata comes IN to the memory,
    // rdata goes OUT of it.
    modport mem (
        input  wdata, waddr, raddr, wclken, wfull, wclk,
        output rdata
    );
endinterface


module fifo1 #(parameter DSIZE = 8,
               parameter ASIZE = 4)
    (output [DSIZE-1 : 0] rdata,
     output               wfull,
     output               rempty,
     output               almost_full,
     output               almost_empty,
     input  [DSIZE-1 : 0] wdata,
     input                winc, wclk, wrst_n,
     input                rinc, rclk, rrst_n);

    logic[ASIZE-1:0] waddr, raddr;
    logic[ASIZE:0]   wptr,  rptr, wq2_rptr, rq2_wptr;

    // interface instance for the memory block
    fifo_mem_if #(.DATASIZE(DSIZE), .ADDRSIZE(ASIZE)) mem_if ();

    assign mem_if.wdata  = wdata;
    assign mem_if.waddr  = waddr;
    assign mem_if.raddr  = raddr;
    assign mem_if.wclken = winc;   // only mismatch vs. mem_if's own names
    assign mem_if.wfull  = wfull;
    assign mem_if.wclk   = wclk;
    assign rdata         = mem_if.rdata;

    // `.*` works below because every local signal in this scope already has
    // the exact same name as the matching submodule port (that's why the
    // original skeleton names things this way).
    sync_r2w  #(.ADDRSIZE(ASIZE))    sync_r2w (.*);
    sync_w2r  #(.ADDRSIZE(ASIZE))    sync_w2r (.*);

    fifomem #(.DATASIZE(DSIZE), .ADDRSIZE(ASIZE)) fifomem (.mif(mem_if.mem));

    rptr_empty #(ASIZE) rptr_empty (.*);

    wptr_full  #(ASIZE) wptr_full  (.*);

endmodule


module fifomem #(parameter DATASIZE = 8, // Memory data word width
                  parameter ADDRSIZE = 4) // Number of mem address bits
    (fifo_mem_if.mem mif);

    `ifdef VENDORRAM
     // instantiation of a vendor's dual-port RAM
     vendor_ram mem (.dout(mif.rdata), .din(mif.wdata),
                     .waddr(mif.waddr), .raddr(mif.raddr),
                     .wclken(mif.wclken),
                     .wclken_n(mif.wfull), .clk(mif.wclk));
    `else
     // RTL Verilog memory model

     localparam DEPTH = 1<<ADDRSIZE;
     logic [DATASIZE-1:0] mem [0:DEPTH-1];

     assign mif.rdata = mem[mif.raddr];

     always_ff @(posedge mif.wclk)
        if (mif.wclken && !mif.wfull) mem[mif.waddr] <= mif.wdata;

    `endif

endmodule


module sync_r2w #(parameter ADDRSIZE = 4)
    (output logic [ADDRSIZE:0] wq2_rptr,
     input [ADDRSIZE:0] rptr,
     input wclk, wrst_n);

    logic [ADDRSIZE:0] wq1_rptr;

    always_ff @(posedge wclk or negedge wrst_n)
    if (!wrst_n) {wq2_rptr,wq1_rptr} <= 0;
    else {wq2_rptr,wq1_rptr} <= {wq1_rptr,rptr};

endmodule

module sync_w2r #(parameter ADDRSIZE = 4)
    (output logic [ADDRSIZE:0] rq2_wptr,
     input [ADDRSIZE:0] wptr,
     input rclk, rrst_n);

    logic [ADDRSIZE:0] rq1_wptr;

    always_ff @(posedge rclk or negedge rrst_n)
        if (!rrst_n) {rq2_wptr,rq1_wptr} <= 0;
        else {rq2_wptr,rq1_wptr} <= {rq1_wptr,wptr};

endmodule



module rptr_empty #(parameter ADDRSIZE = 4)
(
    output logic                 rempty,
    output logic [ADDRSIZE-1:0]  raddr,
    output logic [ADDRSIZE:0]    rptr,
    output logic                 almost_empty,

    input  logic [ADDRSIZE:0]    rq2_wptr,
    input  logic                 rinc,
    input  logic                 rclk,
    input  logic                 rrst_n
);

    localparam int DEPTH = (1 << ADDRSIZE);
    localparam int ALMOST_EMPTY_LEVEL = DEPTH / 4;

    logic [ADDRSIZE:0] rbin;
    logic [ADDRSIZE:0] rgraynext;
    logic [ADDRSIZE:0] rbinnext;

    logic [ADDRSIZE:0] synced_wbin;
    logic [ADDRSIZE:0] used;

    logic rempty_val;
    logic almost_empty_next;


    function automatic logic [ADDRSIZE:0] gray2bin(
        input logic [ADDRSIZE:0] gray
    );
        logic [ADDRSIZE:0] bin;

        bin[ADDRSIZE] = gray[ADDRSIZE];

        for (int i = ADDRSIZE-1; i >= 0; i--) begin
            bin[i] = bin[i+1] ^ gray[i];
        end

        return bin;
    endfunction


    assign raddr = rbin[ADDRSIZE-1:0];

    assign rbinnext =
        rbin + (rinc & ~rempty);

    assign rgraynext =
        (rbinnext >> 1) ^ rbinnext;


    // Empty detection
    assign rempty_val =
        (rgraynext == rq2_wptr);


    // Almost-empty detection
    always_comb begin
        synced_wbin = gray2bin(rq2_wptr);

        used = synced_wbin - rbinnext;

        almost_empty_next =
            (used <= ALMOST_EMPTY_LEVEL);
    end


    // Read pointer
    always_ff @(posedge rclk or negedge rrst_n) begin
        if (!rrst_n) begin
            rbin <= '0;
            rptr <= '0;
        end
        else begin
            rbin <= rbinnext;
            rptr <= rgraynext;
        end
    end


    // Empty flag
    always_ff @(posedge rclk or negedge rrst_n) begin
        if (!rrst_n)
            rempty <= 1'b1;
        else
            rempty <= rempty_val;
    end


    // Almost-empty flag
    always_ff @(posedge rclk or negedge rrst_n) begin
        if (!rrst_n)
            almost_empty <= 1'b1;
        else
            almost_empty <= almost_empty_next;
    end

endmodule



module wptr_full  #(parameter ADDRSIZE = 4)
    (output logic                 wfull,
     output logic [ADDRSIZE-1 :0] waddr,
     output logic [ADDRSIZE   :0] wptr,
     output logic                 almost_full,
     input  logic [ADDRSIZE   :0] wq2_rptr,
     input  logic                 winc, wclk, wrst_n);


    localparam int DEPTH = (1 << ADDRSIZE);
    localparam int ALMOST_FULL_LEVEL = (DEPTH * 3) / 4;

    logic [ADDRSIZE:0] wbin;
    logic [ADDRSIZE:0] wgraynext;
    logic [ADDRSIZE:0] wbinnext;

    logic [ADDRSIZE:0] synced_rbin;
    logic [ADDRSIZE:0] used;

    logic              wfull_val;
    logic              almost_full_next;


    function automatic logic [ADDRSIZE:0] gray2bin(
        input logic [ADDRSIZE:0] gray
    );
        logic [ADDRSIZE:0] bin;

        bin[ADDRSIZE] = gray[ADDRSIZE];

        for (int i = ADDRSIZE-1; i >= 0; i--) begin
            bin[i] = bin[i+1] ^ gray[i];
        end

        return bin;
    endfunction


    always_ff @(posedge wclk or negedge wrst_n)
        if (!wrst_n) {wbin, wptr} <= 0;
        else         {wbin, wptr} <= {wbinnext, wgraynext};

    assign waddr     = wbin[ADDRSIZE-1:0];

    assign wbinnext  = wbin + (winc & ~wfull);

    assign wgraynext = (wbinnext >> 1) ^ wbinnext;


    always_comb begin

        synced_rbin = gray2bin(wq2_rptr);

        used = wbinnext - synced_rbin;

        almost_full_next = (used >= ALMOST_FULL_LEVEL);
    end

    assign wfull_val = (wgraynext=={~wq2_rptr[ADDRSIZE:ADDRSIZE-1], wq2_rptr[ADDRSIZE-2:0]});

    // Full flag
    always_ff @(posedge wclk or negedge wrst_n) begin
        if (!wrst_n)
            wfull<= 1'b0;
        else
            wfull <= wfull_val;
    end



    always_ff @(posedge wclk or negedge wrst_n) begin
        if (!wrst_n)
            almost_full <= 1'b0;
        else
            almost_full <= almost_full_next;
    end


endmodule
