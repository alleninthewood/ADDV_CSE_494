# ============================================================================
# dc_compile.tcl -- Design Compiler synthesis script for fifo1
#                    (Lab #1 Part I synthesis requirements)
#
# Uses the same OSU FreePDK 45nm standard-cell library (gscl45nm.db) and
# $PDK_DIR environment variable as Lab #0's synth/compile_dc.tcl -- no extra
# setup needed beyond sourcing ~/lab0/env.cshrc (which sets $PDK_DIR) before
# running this, same as for VCS.
#
# Usage (from this syn/ directory, inside tcsh with env.cshrc sourced):
#     dc_shell -f dc_compile.tcl |& tee dc_compile.log
# ============================================================================

set OSU_FREEPDK [format "%s%s" [getenv "PDK_DIR"] "/osu_soc/lib/files"]
set search_path [concat $search_path $OSU_FREEPDK "../rtl"]

# alib_library_analysis_path is where DC caches its per-library analysis
# (the .alib files). The course library directory above is read-only to
# students, so pointing this at it (as Lab #0's script does) fails with
# OPT-1313 "not writable" and silently aborts compile_ultra. Point it at
# this local, writable syn/ directory instead -- DC creates its own
# alib-<version>/ cache folder here.
set alib_library_analysis_path "."

set target_library "gscl45nm.db"
set link_library    [concat [list $target_library] [list dw_foundation.sldb]]

set DESIGN_NAME "fifo1"

file mkdir reports

# ---- read RTL --------------------------------------------------------------
# rtl/fifo1.sv is self-contained: fifo_mem_if + fifo1 + fifomem + sync_r2w +
# sync_w2r + rptr_empty + wptr_full all live in this one file. fifo1's own
# top-level ports are plain logic (fifo_mem_if is only used INTERNALLY, for
# the fifomem instantiation) -- so no synthesis-only flat-port wrapper is
# needed. Elaborate fifo1 directly.
analyze -format sverilog { ../rtl/fifo1.sv }

elaborate $DESIGN_NAME
current_design $DESIGN_NAME
link
check_design > reports/check_design.rpt
uniquify

# ---- constraints (clocks, CDC false paths, I/O delays) ---------------------
source constraints.sdc

# ---- compile ----------------------------------------------------------------
compile_ultra

# ---- reports required by the lab -------------------------------------------
# 1) max frequency per clock domain: look at worst negative slack (WNS) in
#    each domain's report below. Achievable period = constrained period -
#    WNS (WNS is negative when timing is violated); max freq = 1/that period.
#    See README.md for the sweep method to converge on the true Fmax.
report_clock                                          > reports/clocks.rpt
report_timing -from [get_clocks wclk] -to [get_clocks wclk] \
    -delay_type max -max_paths 5                      > reports/wr_domain_timing.rpt
report_timing -from [get_clocks rclk] -to [get_clocks rclk] \
    -delay_type max -max_paths 5                      > reports/rd_domain_timing.rpt

# 2) constraints applied (echoes the SDC + confirms the CDC groups took effect)
report_clocks                                         > reports/clock_groups.rpt
report_constraint -all_violators                      > reports/constraint_violations.rpt

# 3) area and power
report_area -hierarchy                                > reports/area.rpt
report_power -hierarchy                               > reports/power.rpt

write -format ddc     -hierarchy -output ${DESIGN_NAME}_netlist.ddc
write -format verilog -hierarchy -output ${DESIGN_NAME}_netlist.v

quit
