# ============================================================================
# constraints.sdc -- timing constraints for fifo1
#
# Two independent clocks (write and read side), plus the CDC handling the
# lab explicitly asks for: paths that cross wclk<->rclk must be marked
# false/asynchronous so Design Compiler doesn't try (and fail) to close
# timing on paths that are actually protected by the sync_r2w/sync_w2r
# 2-flop synchronizers, not by combinational timing.
#
# Periods below are starting points -- see README.md in this folder for how
# to sweep them to find each domain's actual max frequency.
# ============================================================================

create_clock -name wclk -period 10.0 [get_ports wclk]   ;# 100 MHz target
create_clock -name rclk -period 12.0 [get_ports rclk]   ;# ~83 MHz target

# The two clock domains are asynchronous to each other by design (that's the
# whole point of the FIFO). This tells STA to treat every path that would
# cross between wclk and rclk as false, instead of the tool trying to time a
# path it can never actually close -- the correct way to constrain a CDC
# boundary that's protected by synchronizers rather than by timing.
set_clock_groups -name async_clocks -asynchronous \
    -group [get_clocks wclk] \
    -group [get_clocks rclk]

# Reasonable placeholder I/O timing so the tool has budget to optimize
# input/output paths against. Adjust to match whatever actually drives/reads
# these ports in your system if you need tighter numbers.
set_input_delay  -clock wclk 2.0 [get_ports {winc wdata[*]}]
set_input_delay  -clock rclk 2.0 [get_ports rinc]

set_output_delay -clock wclk 2.0 [get_ports {wfull almost_full}]
set_output_delay -clock rclk 2.0 [get_ports {rdata[*] rempty almost_empty}]

# resets are asynchronous inputs; add_delay so they don't overwrite the
# input delays already set above on shared clocks
set_input_delay -clock wclk 2.0 [get_ports wrst_n] -add_delay
set_input_delay -clock rclk 2.0 [get_ports rrst_n] -add_delay
