# Lab 1 - Part I: Asynchronous FIFO

Cummings-style dual-clock (async) FIFO, SystemVerilog implementation and
verification for CSE 494 Lab 1 Part I.

## Structure

- `rtl/fifo1.sv` — FIFO RTL: `fifo_mem_if` interface + `fifomem`, `sync_r2w`,
  `sync_w2r`, `rptr_empty`, `wptr_full` submodules. Uses `always_ff`/`always_comb`
  and `logic` throughout, `.*` implicit port connections, and an interface/modport
  for the memory block, per the lab's SystemVerilog requirements.
- `tb/tb_fifo1.sv` — self-checking testbench: reset/empty check, fill-to-full
  with `almost_full` check at the 3/4 point, overflow attempt, drain-to-empty
  with `almost_empty` check at the 1/4 point, and a concurrent (`fork...join`)
  read/write stress test across two different clock periods.
- `syn/dc_compile.tcl` — Design Compiler synthesis script (OSU FreePDK45,
  `gscl45nm.db` + `dw_foundation.sldb`).
- `syn/constraints.sdc` — clock/IO timing constraints, with the two clock
  domains declared as an asynchronous clock group.
- `Makefile` — `make run` (VCS compile + simulate), `make verdi` (waveform
  viewer), `make synth` (Design Compiler), `make clean`.

## Usage (on the course VCS/DC environment)

```
make run     # compile + simulate, expect "TB_FIFO1: ALL TESTS PASSED"
make verdi   # open the waveform in Verdi
make synth   # run Design Compiler synthesis, reports land in syn/reports/
```
